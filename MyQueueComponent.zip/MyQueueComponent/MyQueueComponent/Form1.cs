﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyQueueComponent
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.DataBindings.Add("Text", myQueue1, "ElemanEkleEnqueue");
            textBox2.DataBindings.Add("Text", myQueue1, "EnTepedekiElemanPeek");
            textBox3.DataBindings.Add("Text", myQueue1, "ElemanSayısıCount");
            textBox4.DataBindings.Add("Text", myQueue1, "ElemanVarMıContains");
            textBox5.DataBindings.Add("Text", myQueue1, "EnTepedekiElemanıSilDequeue");
            textBox6.DataBindings.Add("Text", myQueue1, "TumElemanlarıSilClean");
        }
    }
}
