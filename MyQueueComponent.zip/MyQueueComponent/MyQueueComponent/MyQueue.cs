﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyQueueComponent
{
    public partial class MyQueue : Component
    {

        public int[] a = new int[20];
        public int ElemanEkleEnqueue
        {
            get
            {
                for(int i = 0; i < a.Length; i++)
                {
                    a[i] = i+1;
                }
                return a[5];
            }
        }

        public int EnTepedekiElemanPeek
        {
            get
            {
                return a[0];
            }
        }

        public int ElemanSayısıCount
        {
            get
            {
                return a.Length;
            }
        }

        public bool ElemanVarMıContains
        {
            get
            {
                for (int i = 0; i < a.Length; i++)
                {
                    if (8 == a[i])
                    {
                        return true;
                    }
                }
                return false;
            }
        }    
        
        public int EnTepedekiElemanıSilDequeue
        {
            get
            {
                Array.Clear(a, 0, 1);
                return a[0];
            }
        }

        public int TumElemanlarıSilClean
        {
            get
            {
                Array.Clear(a, 0, a.Length);
                return a[4];
            }
        }

        public MyQueue()
        {
            InitializeComponent();
        }

        public MyQueue(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
    }
}
